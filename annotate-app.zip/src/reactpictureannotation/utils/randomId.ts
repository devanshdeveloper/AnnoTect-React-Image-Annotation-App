import { v4 as uuidv4 } from 'uuid';
export default function randomID(len = 6) {
 return  uuidv4()
}
